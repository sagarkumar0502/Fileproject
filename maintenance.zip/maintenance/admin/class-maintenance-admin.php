<?php
class mtnc_Admin {

	private $plugin_name;

	private $version;

	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
        $this->admin_init();

	}
    
    public function admin_init(){
        
        add_action( 'admin_menu', [$this,'mtnc_register_settings_menu_page'] );
    }
    /**
     * Register a custom menu page.
     */
    function mtnc_register_settings_menu_page() {
        
        add_menu_page(
            __( 'Maintenance', 'textdomain' ),
            'Maintenance',
            'manage_options',
            'maintenance',
            [$this,'mtnc_menu_page'],
            'dashicons-admin-tools',
            200
        );
        
    }
    public function mtnc_menu_page($current = 'homepage'){
    
        echo '<h2 class="title">Maintenance<h2>';
        $tabs = array( 'welcome' => 'Welcome', 'seo' => 'SEO', 'themes' => 'Themes', 'page-builder' => 'Page Builder', 'access' => 'Access', 'advanced' => 'Advanced', 'license' => 'License' );
        echo '<div id="icon-themes" class="icon32"><br></div>';
        echo '<h2 class="nav-tab-wrapper">';
        foreach( $tabs as $tab => $name ){
            $class = ( $tab == $current ) ? ' nav-tab-active' : '';
            echo "<a class='nav-tab$class' href='?page=maintenance&tab=$tab'>$name</a>";
    
        }
        echo '</h2>';  
      
    }

	/**
	 * Register the stylesheets for the admin area.
	 */
	public function enqueue_styles($hook_suffix) {
	   
        if($hook_suffix=='toplevel_page_maintenance'){
            
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/maintenance-admin.css', array(), $this->version, 'all' );
        
        }

	}

	/**
	 * Register the JavaScript for the admin area.
	 */
	public function enqueue_scripts($hook_suffix) {
	   
       if($hook_suffix=='toplevel_page_maintenance'){

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/maintenance-admin.js', array( 'jquery' ), $this->version, false );
        
        }

	}

}
