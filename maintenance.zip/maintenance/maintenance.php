<?php
/**
 * Plugin Name:       Maintenance
 * Plugin URI:        #
 * Description:       Maintenance plugin description.
 * Version:           5.0
 * Author:            sagar
 * Author URI:        #
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       maintenance
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'MAINTENANCE_VERSION', '5.0' );

/**
 * The code that runs during plugin activation.
 */
function mtnc_activate() {

}

/**
 * The code that runs during plugin deactivation.
 */
function mtnc_deactivate() {

}

register_activation_hook( __FILE__, 'mtnc_activate' );
register_deactivation_hook( __FILE__, 'mtnc_deactivate' );


require plugin_dir_path( __FILE__ ) . 'includes/class-maintenance.php';

/**
 * Eexecution of the plugin.
 */
function run_mtnc() {

	$plugin = new MTNC();
	$plugin->run();

}
run_mtnc();
