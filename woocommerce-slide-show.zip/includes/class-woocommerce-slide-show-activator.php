<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com/about/anuj
 * @since      1.0.0
 *
 * @package    Woocommerce_Slide_Show
 * @subpackage Woocommerce_Slide_Show/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Woocommerce_Slide_Show
 * @subpackage Woocommerce_Slide_Show/includes
 * @author     Anuj Panwar <http://example.com/about/anujabout>
 */
class Woocommerce_Slide_Show_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
