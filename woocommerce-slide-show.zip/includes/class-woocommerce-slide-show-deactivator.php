<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://example.com/about/anuj
 * @since      1.0.0
 *
 * @package    Woocommerce_Slide_Show
 * @subpackage Woocommerce_Slide_Show/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Woocommerce_Slide_Show
 * @subpackage Woocommerce_Slide_Show/includes
 * @author     Anuj Panwar <http://example.com/about/anujabout>
 */
class Woocommerce_Slide_Show_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
