<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       http://example.com/about/anuj
 * @since      1.0.0
 *
 * @package    Woocommerce_Slide_Show
 * @subpackage Woocommerce_Slide_Show/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Woocommerce_Slide_Show
 * @subpackage Woocommerce_Slide_Show/includes
 * @author     Anuj Panwar <http://example.com/about/anujabout>
 */
class Woocommerce_Slide_Show_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'woocommerce-slide-show',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
